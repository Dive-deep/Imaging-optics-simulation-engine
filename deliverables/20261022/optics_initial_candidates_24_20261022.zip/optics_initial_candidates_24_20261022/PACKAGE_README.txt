24개 초기 광학 처방 패키지 (2026-10-22)

주요 파일:
experiments/candidates_20261022/candidates.json : 24개 입력 처방과 계산 결과, 상태, 생성 이력
experiments/candidates_20261022/METHOD_KO.md : 수식·특허·최적화·선정·검증 과정과 한계
experiments/candidates_20261022/reports/candidate_report.html : 외부 연결 없이 여는 후보 선택 보고서
experiments/candidates_20261022/reports/candidate_layouts_and_mtf.pdf : 후보당 한 페이지,24쪽
experiments/candidates_20261022/reports/candidate_contact_sheet.png : 24개 단면 전체 보기

모두 첫 렌즈 clear diameter50mm 대안이며 실제EPD는43.20–43.96mm입니다.
NA≥0.7은RGB각각의축상rim 기준, 상고6.4mm는588nm chief 기준입니다.
파동MTF의미수렴/모델적용불가 상태를 그대로 보존했습니다.
기하MTF진단은 회절MTF가 아니며 모든후보가 높은 전시야MTF를 달성한것은 아닙니다.
DB의확정학습label보다는 후속탐색의 초기조건으로 사용하십시오.

재현: Python3.12, NumPy2.3.5, SciPy1.17.0, matplotlib. native C커널에는C컴파일러가필요합니다.
압축해제한루트에서:
python -m pip install -e .
python -m pip install matplotlib
python experiments/candidates_20261022/native/build.py
python experiments/candidates_20261022/render_report.py experiments/candidates_20261022/candidates.json --output reports_regenerated

한국어그림을재생성할때NotoSansCJK등한국어폰트가필요합니다. 이미제공한HTML/PDF/PNG는폰트설치없이읽을수있습니다.
compiled .so와중복PNG는배포압축에서제외했습니다. core원본은GitHub commit e347d56b238f86cedd239921335245f85163b806이며원본소스를변경하지않았습니다.
이ZIP은이번실험과필요한소스/검증/공개참고자료의패키지이며Git저장소전체백업은아닙니다.
GitHub: https://github.com/Dive-deep/Imaging-optics-simulation-engine

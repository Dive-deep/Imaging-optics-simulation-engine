CT20 초기 후보군 23개 — 2026-10-22

최신 후보 데이터: experiments/candidates_ct20_20261022/candidates.json
생성 과정: experiments/candidates_ct20_20261022/METHOD_KO.md
전체 후보 탐색: experiments/candidates_ct20_20261022/reports/candidate_report.html
후보별 단면·RI·왜곡·spot·MTF: 같은 reports의 candidate_layouts_and_mtf.pdf
전체 단면: 같은 reports의 candidate_contact_sheet.png

모든 독립 합격 후보를 유지했습니다. 하나의 winner를 선정하지 않았습니다.
각 렌즈 축상 중심 두께는 2 mm 초과, 20 mm 이하입니다.
고NA scalar 파동 결과의 underresolved/not_applicable 상태를 확인하십시오.
기하 MTF는 별도 진단이며 회절 학습 정답으로 인증한 데이터가 아닙니다.

코드 재현: python -m pip install -e .
native 빌드: python experiments/candidates_ct20_20261022/native/build.py
그림 재생성에는 matplotlib 및 한국어 폰트가 추가로 필요합니다.
보고서는 브라우저에서 로컬 파일로 열 수 있고 외부 API나 네트워크가 필요 없습니다.
이전 후보의 코드·입력·검사 이력은 candidates_20261022에 보존되어 있습니다.
이전 HTML/PDF는 별도 기존 ZIP에 있고, 이번 ZIP에는 중복 포함하지 않았습니다.
원본 코어 src/tests는 이 작업에서 변경하지 않았습니다. DB 생성이나 GitHub push는 하지 않았습니다.
